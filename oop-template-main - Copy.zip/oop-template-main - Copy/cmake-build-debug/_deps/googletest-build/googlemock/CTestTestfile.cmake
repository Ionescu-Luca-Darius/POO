# CMake generated Testfile for 
# Source directory: C:/Users/User/Desktop/oop-template-main/cmake-build-debug/_deps/googletest-src/googlemock
# Build directory: C:/Users/User/Desktop/oop-template-main/cmake-build-debug/_deps/googletest-build/googlemock
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
subdirs("../googletest")
